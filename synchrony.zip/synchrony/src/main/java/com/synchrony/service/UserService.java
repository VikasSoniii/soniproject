package com.synchrony.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synchrony.entity.User;
import com.synchrony.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	// Save user details
	public User saveImage(User user) {
		return userRepository.save(user);
	}

	// View Images for User
	public User viewImage(int id) {

		Optional<User> user = userRepository.findById(id);
		User userObj = new User();

		if (user.isPresent())
			userObj = user.get();

		return userObj;
	}

	// Delete Images for User
	public void deleteImage(int id) {
		Optional<User> user = userRepository.findById(id);

		if (user.isPresent())
			userRepository.deleteById(id);
	}

}
