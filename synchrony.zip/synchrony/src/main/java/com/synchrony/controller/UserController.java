package com.synchrony.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.synchrony.entity.User;
import com.synchrony.service.UserService;

@RestController
@RequestMapping("/synchrony")
public class UserController {
	
	Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserService userService;
	/*
	@GetMapping("/hello")
	public String test() {
		logger.info("---inside test methods---");
		return "Hello Synchrony!";
	}*/
	
	@GetMapping("/viewImages/{id}")
	public User viewImages(@PathVariable int id) {
		logger.info("---inside viewImages methods---");
		return userService.viewImage(id);
	}
	
	@PostMapping("/saveUser")
	public User saveUser(@RequestBody User user) {
		logger.info("---inside saveUser methods---");
		return userService.saveImage(user);
	}
	
	@DeleteMapping("/deleteImages/{id}")
	public String deleteImages(@PathVariable int id) {
		logger.info("---inside deleteImages methods---");
		userService.deleteImage(id);
		return "Images deleted successfully!";
	}
}
